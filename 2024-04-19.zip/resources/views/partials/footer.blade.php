<div class="nk-footer">
    <div class="container-fluid">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright">{{__('copy_right_text')}}
            </div>
            <div class="nk-footer-links">
                <ul class="nav nav-sm">
{{--                    <li class="nav-item"><a class="nav-link" href="https://spagreen.net/" title="SpaGreen Creative"><span style="color: #999;">Developed by </span> SpaGreen Creative</a></li>--}}
                    <li class="nav-item"><a class="nav-link" href="#" style="color: #999;" title="Version:V2.0.0">V2.0</a></li>
                    <li class="nav-item"><a class="nav-link" href="https://greenx.com.bd/terms-condition">Terms</a></li>
                    <li class="nav-item"><a class="nav-link" href="https://greenx.com.bd/privacy-policy">Privacy</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
